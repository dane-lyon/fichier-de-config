#!/bin/bash

#### changement de fond ecran ouverture de session ubuntu ####
# - récupère la valeur du groupe et attribut en fonction les fond ecran génére par esu
# - ver 1.0.1
# - 12 mars 2015
# - CALPETARD Olivier

#les fichiers se trouvent dans icones$ 
#lecture du groupe ESU
gm_esu=grp_eole

if [ -f "/etc/GM_ESU" ];then
echo "Le PC est dans le groupe esu"
gm_esu=$(cat /etc/GM_ESU)
fi



#administratif = 10000
#prof = 10001
#eleve = 10002
sleep 3

if [ $GROUPS -eq 10000 ]
then
   variable=Admin
cp /tmp/netlogon/icones/$gm_esu/_Machine/Bureau/*.desktop  /$HOME/Desktop/
cp /tmp/netlogon/icones/$gm_esu/administratifs/Bureau/*.desktop  /$HOME/Desktop/
chmod +x /$HOME/Desktop/*.desktop

elif [ $GROUPS -eq 10001 ]
then
   variable=Prof
cp /tmp/netlogon/icones/$gm_esu/_Machine/Bureau/*.desktop  /$HOME/Desktop/
cp /tmp/netlogon/icones/$gm_esu/professeurs/Bureau/*.desktop  /$HOME/Desktop/
chmod +x /$HOME/Desktop/*.desktop

elif [ $GROUPS -eq 10002 ]
then
   variable=Eleve
cp /tmp/netlogon/icones/$gm_esu/_Machine/Bureau/*.desktop  /$HOME/Desktop/
cp /tmp/netlogon/icones/$gm_esu/eleves/Bureau/*.desktop  /$HOME/Desktop/
chmod +x /$HOME/Desktop/*.desktop
else [ $GROUPS -lt 10000 ]
 gsettings set org.gnome.desktop.background picture-uri "file:///home/$USER/Images/images.jpg"

exit 0
fi

wallpaper=$(cat /tmp/netlogon/icones/$gm_esu/$variable.txt)

gsettings set org.gnome.desktop.background picture-uri "file:///"$wallpaper""

gsettings set com.canonical.indicator.session show-real-name-on-panel true

gsettings set com.canonical.Unity integrated-menus true

dconf write /org/compiz/profiles/unity/plugins/unityshell/icon-size 32
gsettings set com.canonical.Unity always-show-menus true

#lancement de conky avec lecture du fichier de conf
conky -c /tmp/netlogon/icones/posteslinux/conky/conky.cfg

exit 0
