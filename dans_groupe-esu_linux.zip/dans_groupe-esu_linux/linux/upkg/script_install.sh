#!/bin/bash

# Indiquer ici les commandes que vous voulez effectuer (décommenté).

###Quelques exemples :

# Installer le programme "htop" sur tous les postes :
#sudo apt install htop -y

# Désinstaller le logiciel "totem" sur tous les postes :
#sudo apt remove totem -y

# Faire toutes les maj + purge des fichiers inutiles sur l'ensemble des postes :
#sudo apt update ; sudo apt full-upgrade -y ; sudo apt autoremove --purge -y ; sudo apt clean ;

# Changer le moteur de recherche par défaut de firefox par "duckduckgo" (le script met Qwant par défaut) :
#echo "user_pref(\"browser.startup.homepage\", \"https://duckduckgo.com\");" >> /usr/lib/firefox/defaults/pref/channel-prefs.js


exit
